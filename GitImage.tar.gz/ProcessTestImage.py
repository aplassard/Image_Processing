#!/usr/bin/env python
'''
    Code to process test image
'''
import numpy as np
import imageTransforms
from common import *
import Image
from calculateFeatures import calculatefeatures
from scipy.ndimage import watershed_ift

__author__='Andrew Plassard'
__version__='1.0'
__email__='andrew.plassard@gmail.com'

def getWalkerParameters(arr,size,factor=4):
    '''
    Input: The image in numpy array format
           The size of the window
           The factor by which to divide the window to get step size, default 4
    Output: xrange of x steps
            xrange of y steps
            step size
            
    Example:
    >>> xvals,yvals,step = getWalkerParameters(imagearay,80)
    '''
    s=arr.shape
    step=size/factor
    y=xrange(0,s[0]-size,step)
    x=xrange(0,s[1]-size,step)
    return x,y,step
            
def iterRegions(x,y,size,arr):
    for i in xrange(size):
        for j in xrange(size):
            try:
                arr[i+y,j+x]+=1
            except:
                pass
    return arr

def saveImages(arrdict,keydict,threshold=None):
    for key in keydict.keys():
        if threshold==None:
            savearray(arrdict[key],keydict[key]+'.tif')
        else:
            savearray(arrdict[key],keydict[key]+'.'+str(threshold)+'.tif')
        
def runWalk(imgline,size,ML, maskGen):
    '''
    Input:
        The line containing the image
        The window size
        the object of type ml
        the mask generating object
    Output:
        A series of arrays of the different subtypes of the image
    '''
    fillThreshold=0.15
    line = imgline.strip().split('\t')
    img = line[0]
    img = Image.open(img)
    imgs = imageTransforms.normalizeImage(img)
    x,y,step=getWalkerParameters(imgs[grayscale],size,factor=8)

    arraydict = []
    for key in ML.intdict.keys():
        arraydict.append(np.zeros_like(imgs[grayscale],dtype=int))
        temp=ML.intdict[key]

    #make binary image mask by thresholding on background
    tempColorImg=imgs['RGB']
    imageMask=maskGen.getMask(tempColorImg, 'background')
    np.savetxt("mask.txt", imageMask)
    for i in x:
        for j in y:
            print
            print i,i+size,j,j+size,
            subMask=imageMask[i:i+size, j:j+size]
            percentFilled=sum(subMask)/(size*size)
            #if subregion has enough 1's in it, the go ahead, else do nothing
            if(percentFilled>=fillThreshold):
                try:
                    f=np.array(calculatefeatures(imgs,left=i,right=i+size,top=j,bottom=j+size),dtype=float)
                    labels = ML.getLabels(f)
                    for k in xrange(len(labels)):
                        print ML.intdict[labels[k]],
                        arraydict[labels[k]]=iterRegions(i,j,size,arraydict[labels[k]])                            
                except ValueError:
                    for i in xrange(len(vector)):
                        print vector[i],
            else:
                print "Skipping"

    print
    print 'Saving Images'
    saveImages(arraydict,ML.intdict)
    nimages=[]
    for j in xrange(25):
        for i in xrange(len(arraydict)):
            t = j
            nimages.append(thresholdImage(arraydict[i],imgs[RGB],t))
        saveImages(nimages,ML.intdict,threshold=t)
    print 'Finding Local Maxima'
    markers = getLocalMaxima(arraydict[0])
    print 'Running Watershed'
    watersheded = runWatershed(markers,imgs[grayscale])
    savearray(watersheded,'watersheded_image.tif')
    
def runWatershed(markers,arr):
	res = watershed_ift(arr,markers)
	
    

def thresholdImage(vals,arr,threshold):
    for i in xrange(vals.shape[0]):
        for j in xrange(vals.shape[1]):
            if vals[i,j]<=threshold:
                if len(arr.shape)<3:
                    arr[i,j]=0
                else:
                    for k in xrange(arr.shape[2]):
                        arr[i,j,k]=0
    return arr
    
def getLocalMaxima(arr,size):
	'''
	Input:
		2D numpy array
	Output:
		2D numpy array of local maxima
		
	Usage:
		 >>> marray = getLocalMaxima(arr)
	'''	
	marray = np.zeros_like(arr,dtype=int)
	for i in xrange(size,arr.shape[0]-1,size):
		for j in xrange(size,arr.shape[1]-1,size):
			val = arr[i,j]
			print val,max([arr[i-1,j-1],arr[i-1,j],arr[i-1,j+1],arr[i,j+1],arr[i+1,j+1],arr[i,j-1],arr[i+1,j],arr[i+1,j-1],1])
			if val >= max([arr[i-1,j-1],arr[i-1,j],arr[i-1,j+1],arr[i,j+1],arr[i+1,j+1],arr[i,j-1],arr[i+1,j],arr[i+1,j-1],1]):
				marray[i,j]=1
	return marray
			
			
def localMax(imageArray):
	maxX=imageArray.shape[0]
	maxY=imageArray.shape[1]
	indexX=0
	indexY=0
	p=imageArray.argmax()
	while( p>= maxY):
		indexX=indexX+1
		p=p%maxY
	indexY=p
